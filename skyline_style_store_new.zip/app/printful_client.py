import os,requests
API_URL='https://api.printful.com'
class PrintfulClient:
    def __init__(self):
        key=os.environ.get('PRINTFUL_API_KEY')
        if not key: raise RuntimeError('Missing API key')
        self.s=requests.Session(); self.s.headers.update({'Authorization':f'Bearer {key}','Content-Type':'application/json'})
    def _h(self,r):
        if not r.ok: raise RuntimeError(r.text)
        d=r.json(); return d.get('result',d)
    def list_products(self): return self._h(self.s.get(f'{API_URL}/store/products'))
