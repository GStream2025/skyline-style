from flask import Blueprint, render_template, jsonify
from app.models import Product
from app.printful_client import PrintfulClient

main_bp=Blueprint('main',__name__)
PRODUCTS=[Product(1,'Hoodie Skyline',1490,'Hoodie','/static/img/skyline_team.jpg')]

@main_bp.route('/')
def index(): return render_template('index.html', featured_products=PRODUCTS)

@main_bp.route('/printful/test')
def test(): return jsonify(PrintfulClient().list_products())
